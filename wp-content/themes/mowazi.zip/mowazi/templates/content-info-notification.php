<!-- info preview component -->
<div class="info-preview">
    <!-- avatar component -->
    <!-- <div class="avatar avatar-lg" data-avatar="http://localhost:3000/mowazi/wp-content/themes/mowazi/images/avatar-test.svg"></div> -->
    <!-- end of avatar component -->
    <div class="info info-sm">
        <h4 class="info-title">حسين الشرشوبي الشرشوبي</h4>
        <p class="info-subtitle">لقد ذكرتك في المحرر</p>
    </div>
    <!-- end of user preview component -->
</div>