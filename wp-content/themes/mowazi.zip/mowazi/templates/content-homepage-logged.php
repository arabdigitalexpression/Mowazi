<?php
global $post_id;
$user_id = get_current_user_id();

$defaultPostTypes = array( 'articles', 'activities', 'stories', 'games', 'workshops' );
$filteredPostTypes;

$participants = get_query_var('participants');
$age_range = get_query_var('age_range');
$duration = get_query_var('duration');
$post_type_filter = get_query_var('post_type_filter');

$posts_per_page = 10;
$meta_query = array();

if($participants){
    $posts_per_page= -1;
    $meta_query['relation'] = 'AND';
    $meta_query[] = array(
            'key' => 'mo_workshop_activity_participants',
            'value' => $participants
    );
}

if($age_range){
    $posts_per_page= -1;
    $meta_query['relation'] = 'AND';
    $meta_query[] = array(
            'key' => 'mo_workshop_activity_age',
            'value' => $age_range 
    );
}

if($duration){
    $posts_per_page= -1;
    $meta_query['relation'] = 'AND';
    $meta_query[] = array(
            'key' => 'mo_workshop_activity_duration',
            'value' => $duration
    );
}

if($post_type_filter){
    $posts_per_page= -1;
    $filteredPostTypes = array($post_type_filter);
}

?>
<section class="content-section homepage-loggedin">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php get_template_part('sidebars/sidebar-home');?>
                <?php get_template_part('sidebars/sidebar-filters-tags'); ?>
            </div>

            <div class="col-md-9">

                <div class="content-wrapper">
                   <!-- <div class="introDesc">
                        <p>لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر</p>
                        <a href="#" class="btn btn-outline-secondary" data-toggle="modal" data-target="#NewPost">أضف محتوى جديد</a>
                    </div> -->
                    <?php
                    // bookmarked posts
                    $user_bookmarks = get_user_meta( $user_id, 'user_bookmarks', true );
                    $user_bookmarks_arr = array();

                    if ( !empty($user_bookmarks) ) {
                        $user_bookmarks_arr = explode( ',', $user_bookmarks );
                    }

                    if ( !empty($user_bookmarks_arr) ) {
                        $bookmarks_count = 0;
                    ?>
                    <?php } ?>

                    <?php
                    // featured posts
                    $featured_posts = get_posts( array(
                        'post_type'         =>  array( 'articles', 'activities', 'stories', 'games', 'workshops' ),
                        'post_status'       =>  'publish',
                        'posts_per_page'    =>  3,
                        'post_parent'       =>  0,
                        'fields'            =>  'ids',
                        'post__not_in'      =>  $user_bookmarks_arr,
                        
                        'meta_key' => '_is_ns_featured_post', 
                        'meta_value' => 'yes' 
                    ) );

                    if (!empty($featured_posts)) {
                    ?>
                    <?php } ?>
                    
                    <?php
                    // latest posts
                    $latest_posts = get_posts( array(
                        'post_type'         =>  $filteredPostTypes ? $filteredPostTypes : $defaultPostTypes,
                        'post_status'       =>  'publish',
                        'posts_per_page'    =>  $posts_per_page,
                        'post_parent'       =>  0,
                        'fields'            =>  'ids',
                        'post__not_in'      =>  $user_bookmarks_arr,
                        'tax_query'         => array(
                             array(
                                'taxonomy'  => 'category',
                                'field'     => 'term_id',
                                'terms'     => 5,
                                'operator'  =>  'NOT IN'
                            ),
                        ),
                        'meta_query'        =>  $meta_query
                        ) );

                    if (!empty($latest_posts)) {
                    ?>
                    <div class="section-wrapper homepage-content-wrapper">
                        <div class="content-section_header d-flex justify-content-between align-items-center">
                            <h2>المحتوى المنشور مؤخرا</h2> 
                        </div>
                        <div class="row">
                            <!-- <div class="col-md-6 col-xl-4 mz-mb-35">
                                <?php get_template_part('templates/content-suggestions-1'); ?>
                            </div>
                            <div class="col-md-6 col-xl-4 mz-mb-35">
                                <?php get_template_part('templates/content-suggestions-2'); ?>
                            </div> -->
                            <?php 
                            foreach ($latest_posts as $key => $post_id) {
                            ?>
                            <div class="col-md-6 col-xl-4 mz-mb-35">
                                    <!-- <?php //get_template_part('templates/content-card'); ?> -->
                                    <?php get_template_part('templates/content-card_new'); ?>

                            </div>
                            <?php if(($key > 0) && ($key % 4 == 0)): ?>
                                <div class="col-md-6 col-xl-4 mz-mb-35">
                                    <?php $suggestion =  rand(1,2); 
                                        if($suggestion == 1):
                                    ?>
                                    <?php get_template_part('templates/content-suggestions-1'); ?>
                                    <?php else: ?>
                                        <?php get_template_part('templates/content-suggestions-2'); ?>
                                    <?php endif;?>
                                </div>
                            <?php endif;?>
                            <?php } ?>
                        </div>
                        <?php if($posts_per_page == 10):?>
                        <div class="btn-readMore">
                            <?php
                            $load_more_link = apply_filters( 'load_more_link', '<a href="#" class="btn bg-white content-section_btn" data-load>عرض الكل</a>', 'all', $user_bookmarks_arr, array( 5 ), false, $user_id, 3 );

                            if ( !empty($load_more_link) ) {
                                echo $load_more_link;
                            } ?>
                        </div>
                        <?php endif;?>
                    </div>
                    <?php } ?>

                </div>
            </div>  
            <!-- <div class="col-md-3">
                <?php get_template_part('sidebars/sidebar-tags'); ?>
            </div> -->
        </div>
    </div>
</section>

