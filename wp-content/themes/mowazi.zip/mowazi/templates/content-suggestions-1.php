<div class="suggestion-card why-mowazi">
    <div class="suggestion-card-title">
        <h2>ليه موازي؟</h2>
        <p>منصة موازي هي جزأ من حلم ومشروع كبير اننا نخلق مساحة ابداع مفتوحة وامنة</p>
    </div>
    <div class="suggestion-card-content">
        <div class="items">
            <div class="item">
                <div class="item-img">
                    <img src="<?php echo get_template_directory_uri()?>/images/why-mowazi-1.svg" alt="">
                </div>
                <div class="item-text">
                    <h6>محتوي عربي</h6>
                    
                </div>
            </div>	
            <div class="item">
                <div class="item-img">
                    <img src="<?php echo get_template_directory_uri()?>/images/why-mowazi-2.svg" alt="">
                </div>
                <div class="item-text">
                    <h6>مفتوح المصدر</h6>
                   
                </div>
            </div>
            <div class="item">
                <div class="item-img">
                    <img src="<?php echo get_template_directory_uri()?>/images/why-mowazi-1.svg" alt="">
                </div>
                <div class="item-text">
                    <h6>للجميع</h6>
                </div>
            </div>				
        </div>
    </div>
</div>