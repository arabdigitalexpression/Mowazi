<div class="suggestion-card subscribe-mowazi">
    <form>
        <div class="form-group news">
            <label for="news"><h2>اشترك في موازي عبر البريد الإلكتروني</h2></label>
            <div class="email-input">
                <input type="email" required class="form-control" name="news" id="news" aria-describedby="helpId" placeholder="البريد الإلكتروني"  
            data-bv-notempty-message="هذا الحقل لا يمكن ان يكون فارغا" data-bv-emailaddress-message="هذا الحقل لا يمكن ان يكون فارغا">
            </div>
            <button class="btn btn-primary" type="submit"> اشترك</button>
        </div>
    </form>
</div>