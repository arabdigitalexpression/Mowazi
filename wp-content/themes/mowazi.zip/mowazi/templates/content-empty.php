<div class="container">
<!-- empty-content.svg -->
<div class="empty-content text-center">
	<img src="<?php echo get_template_directory_uri() . '/images/empty-content.svg';?>" alt="empty img">
	<h1>لا يوجد محتوي الان</h1>
</div>
</div>