<?php get_header(); ?>

<?php
get_template_part('templates/content-archive');
?>

<?php get_footer(); ?>
