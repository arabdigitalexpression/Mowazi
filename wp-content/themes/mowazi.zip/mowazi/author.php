<?php get_header(); ?>

<?php

get_template_part('templates/content-profile_user');

?>

<?php get_footer(); ?>
