<?php get_header(); ?>

<?php
get_template_part('templates/content-tag');
?>

<?php get_footer(); ?>
