<?php
get_header();

get_template_part('templates/content-empty');

get_footer();
?>